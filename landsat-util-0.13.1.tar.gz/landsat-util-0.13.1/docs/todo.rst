To Do List
++++++++++

- Add alternative projections (currently only option is default web-mercator; EPSG: 3857)
- Include 16-bit image variant in output
- Add support for color correct looping over multiple compressed inputs (currently just 1)
